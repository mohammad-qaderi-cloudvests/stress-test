import sql from 'k6/x/sql';
import { check, fail } from 'k6';

// Configuration
const username = 'xxxxxxxxxxxxxxxxx';
const password = 'xxxxxxxxxxxxxxxxx';
const host = 'xxxxxxxxxxxxxxxxxxx';
const port = 3306;
const database = 'xxxxxxxxxxxxxxx';

const dbUrl = `${username}:${password}@tcp(${host}:${port})/${database}`;

// Test configuration with stages
export const options = {
    stages: [
        { duration: '2m', target: 50 },    // Ramp-up to 50 VUs
        { duration: '5m', target: 50 },    // Stay at 50 VUs
        { duration: '2m', target: 200 },   // Ramp-up to 200 VUs
        { duration: '5m', target: 200 },   // Stay at 200 VUs
        { duration: '2m', target: 500 },   // Ramp-up to 500 VUs
        { duration: '5m', target: 500 },   // Stay at 500 VUs
        { duration: '2m', target: 1000 },  // Ramp-up to 1000 VUs
        { duration: '5m', target: 1000 },  // Stay at 1000 VUs
        { duration: '2m', target: 2000 },  // Ramp-up to 2000 VUs
        { duration: '5m', target: 2000 },  // Stay at 2000 VUs
        { duration: '2m', target: 5000 },  // Ramp-up to 5000 VUs
        { duration: '5m', target: 5000 },  // Stay at 5000 VUs
        { duration: '3m', target: 0 },     // Ramp-down to 0 VUs
    ],
    thresholds: {
        http_req_duration: ['p(95)<2000'], // 95% of requests should be below 2000ms
    },
};

// Initialize database connection
let db = sql.open('mysql', dbUrl);

export function teardown() {
    if (db) {
        console.log("closing database connection...  (if open)  \n");
        db.close();
    }
}

export default function () {
    try {
        const startTime = Date.now();

        const insertQuery = `INSERT INTO firebase_requests (data, full_path, value_path, update_just_one_val, os, addition_ts)   
            VALUES ('{\"level_id\":\"1\",\"level_name\":\"\\u0623\"}', 'students_progress/838011', '', null, 'WEB', 1733650251)`;

        const selectQuery = `  
            SELECT SUM(slide_paragraphs.paragraph_audio_time) AS counter  
            FROM slide_paragraphs  
            JOIN book_slides ON book_slides.slide_id = slide_paragraphs.slide_id  
            WHERE book_slides.book_id = '1231'  
            AND book_slides.slide_status = 'active'  
        `;

        const selectResults = sql.query(db, selectQuery);
        const insertResults = sql.query(db, insertQuery);

        check(insertResults, {
            'is valid insert result': (r) => !!r,
        });

        check(selectResults, {
            'is valid select result': (r) => !!r,
        });

        const endTime = Date.now();
        console.log(`Query executed in ${endTime - startTime}ms`);

    } catch (error) {
        fail('query execution failed');
        console.error(`Database connection or query failed: ${error}`);
    }
}